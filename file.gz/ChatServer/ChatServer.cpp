#include <stdint.h>
#include <stdlib.h>
#include <ostream>
#include <string>

#include "ChatServer.h"
#include "ChatServerConfig.h"
#include "ChatServiceImp.h"
#include "ChatThreadPool.h"
#include "service/ApplicationConfig.h"
#include "util/util_log.h"

using namespace std;

ChatServer g_app;

void ChatServer::initialize()
{
	int32_t ret = loadChatServerConfig();
	if (ret != 0)
	{
		LOG_ERROR("loadChatServerConfig:" << ret);
		exit(-1);
	}

	addService<ChatServiceImp>(ServerConfig::Application + "." + ServerConfig::ServerName + ".ChatServiceObj");
	
    ret = CHAT_THREAD_QUEUE_MGR->initialize(g_stChatServerConfig.iLogicThreadNum);
	if (ret != 0)
	{
		LOG_ERROR("CHAT_THREAD_QUEUE_MGR initialize error, ret:" << ret);
		exit(-1);
	}

	ret = CHAT_THREAD_POOL->initialize(g_stChatServerConfig.iLogicThreadNum);
	if (ret != 0)
	{
		LOG_ERROR("CHAT_THREAD_POOL initialize error, ret:" << ret);
		exit(-1);
	}
	
    LOG_DEBUG("start server ok >>>>>>>>>>>>>>>>>>>>");
}

void ChatServer::destroyApp()
{
	CHAT_THREAD_POOL->finalize();
	LOG_DEBUG("stop server ok >>>>>>>>>>>>>>>>>>>>");
}

int main(int argc, char *argv[])
{
	return g_app.main(argc, argv);
}
