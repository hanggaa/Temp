
#ifndef _CHAT_THREAD_POOL_H_
#define _CHAT_THREAD_POOL_H_

#include <stdint.h>
#include <tr1/memory>
#include <vector>

#include "ChatServiceImp.h"
#include "service/Global.h"
#include "util/util_queue.h"
#include "util/util_singleton.h"
#include "util/util_thread.h"

typedef mfw::CThreadQueue<mfw::SdpCurrentPtr> 	ChatThreadQueue;
typedef tr1::shared_ptr<ChatThreadQueue>		ChatThreadQueuePtr;

class ChatThreadQueueMgr : public mfw::CSingleton<ChatThreadQueueMgr>
{
public:
	ChatThreadQueueMgr();
	~ChatThreadQueueMgr();

public:
	int32_t initialize(uint32_t iThreadNum);
	int32_t pushToQueue(uint32_t iIndex, mfw::SdpCurrentPtr& stSdpCurrentPtr);
	int32_t getThreadQueue(uint32_t iIndex, ChatThreadQueuePtr& ptrThreadQueue);

private:
	// 线程队列
	vector<ChatThreadQueuePtr>		m_vThreadQueue;
};

#define CHAT_THREAD_QUEUE_MGR (ChatThreadQueueMgr::getInstance())

class ChatThread : public mfw::CThreadBase
{
public:
	ChatThread() : m_iThreadId(0), m_stChatServiceImp() {}
	~ChatThread() {}

	void setThreadId(uint32_t iThreadId)
	{
		m_iThreadId = iThreadId;
	}

	uint32_t getThreadId()
	{
		return m_iThreadId;
	}

	void stop()
	{
		mfw::CThread& stCThread = getThread();

		stCThread.terminate();
		stCThread.join();
	}

	void run();

private:
	uint32_t 			m_iThreadId;
	ChatServiceImp 		m_stChatServiceImp;
};

typedef tr1::shared_ptr<ChatThread>		ChatThreadPtr;

class ChatThreadPool : public mfw::CSingleton<ChatThreadPool>
{
public:
	ChatThreadPool();
	~ChatThreadPool();

public:
	int32_t initialize(uint32_t iThreadNum);
	int32_t finalize();

private:
	// 线程
	vector<ChatThreadPtr>		m_vChatThreadPtr;
};

#define CHAT_THREAD_POOL (ChatThreadPool::getInstance())

#endif
