#ifndef _CHATSERVICE_IMP_H_
#define _CHATSERVICE_IMP_H_

#include <stdint.h>
#include <sys/types.h>
#include <map>
#include <string>

#include "ChatService/MTTD.ChatService.h"

class ChatServiceImp : public MTTD::ChatService
{
public:
	virtual void initialize();
    virtual void destroy();
    
    void dispatchThreadPool(uint64_t iHashCode);

public:
	virtual int32_t joinChatRoom(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sFilter, uint32_t iOldType, const string& sOldFilter, const string& sOldRoomKey, string& sRoomKey);
	virtual int32_t leaveChatRoom(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sFilter, const string& sRoomKey);

    virtual int32_t sendChat(const string &sRoomKey, uint32_t iZoneId, uint64_t iUid, const string &sData);
	
    virtual int32_t showChatRoomInfo(const string &sRoomKey, string &sInfo);
	
    virtual int32_t joinChatRoomWithSize(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sFilter, uint32_t iSize, uint32_t iOldType, const string& sOldFilter, uint32_t iOldSize, const string& sOldRoomKey, string& sRoomKey);
	virtual int32_t leaveChatRoomWithSize(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sFilter, uint32_t iSize, const string& sRoomKey);

public:
	void setInMFW(bool bInMFW) { m_bInMFW = bInMFW; }
    uint64_t getHashCode(const string& sKey);

	// **** 每次有接口定义变化, 都需要同步修改这里(等待框架支持) ****
	int handleMfwRequestForThreadPool(string &sRspPayload);

private:
	bool m_bInMFW;

    map<string, uint64_t> m_HashCode;
};
#endif
