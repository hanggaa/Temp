#include <tr1/memory>
#include "util/util_stl.h"

#include "ChatManager.h"
#include "ChatServerConfig.h"
#include "ChatServiceImp.h"
#include "ChatThreadPool.h"
#include "service/Global.h"
#include "service/SdpCurrent.h"
#include "util/util_string.h"

uint64_t MurmurHash64B(string src)
{ 
    static uint64_t seed = 0xEE6B27EB; 
    const uint32_t m = 0x5bd1e995;  
    const int32_t r = 24;  
    uint32_t len = src.length();
    const char* key = src.c_str();

    uint32_t h1 = seed ^ len;  
    uint32_t h2 = 0;  

    const uint32_t * data = (const uint32_t *)key;  

    while(len >= 8)  
    {  
        uint32_t k1 = *data++;  
        k1 *= m; k1 ^= k1 >> r; k1 *= m;  
        h1 *= m; h1 ^= k1;  
        len -= 4;  

        uint32_t k2 = *data++;  
        k2 *= m; k2 ^= k2 >> r; k2 *= m;  
        h2 *= m; h2 ^= k2;  
        len -= 4;  
    }  

    if(len >= 4)  
    {  
        uint32_t k1 = *data++;  
        k1 *= m; k1 ^= k1 >> r; k1 *= m;  
        h1 *= m; h1 ^= k1;  
        len -= 4;  
    }  

    switch(len)  
    {  
        case 3: h2 ^= ((unsigned char*)data)[2] << 16;  
        case 2: h2 ^= ((unsigned char*)data)[1] << 8;  
        case 1: h2 ^= ((unsigned char*)data)[0];  
                h2 *= m;  
    };  

    h1 ^= h2 >> 18; h1 *= m;  
    h2 ^= h1 >> 22; h2 *= m;  
    h1 ^= h2 >> 17; h1 *= m;  
    h2 ^= h1 >> 19; h2 *= m;  

    uint64_t h = h1;  

    h = (h << 32) | h2;  

    return h;  
}  
void ChatServiceImp::initialize()
{
    setInMFW(true);
}

void ChatServiceImp::destroy()
{
}

int32_t ChatServiceImp::joinChatRoom(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sFilter, uint32_t iOldType, const string& sOldFilter, const string& sOldRoomKey, string& sRoomKey)
{
	if (m_bInMFW)
	{
		getCurrent()->setResponse(false);
        // 88 hash 从filter改为iUid，join中的createRoom逻辑会可能重复创建多个，但是逻辑上可以接受
		//dispatchThreadPool(getHashCode(sFilter));
		dispatchThreadPool(getHashCode(UtilString::tostr(iUid)));
		return 0;
	}

    int32_t iRet = 0;

    if (iOldType != 0 && !sOldFilter.empty() && !sOldRoomKey.empty())
    {
        iRet = ChatManager::getInstance()->leaveChatRoom(iZoneId, iUid, iOldType, sOldFilter, sOldRoomKey);
        if (iRet != 0)
        {
            return iRet;
        }
    }
    
    iRet = ChatManager::getInstance()->joinChatRoom(iZoneId, iUid, iType, sFilter, sRoomKey);
    if (iRet != 0)
    {
        return iRet;
    }
 
    return 0;
}

int32_t ChatServiceImp::leaveChatRoom(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sFilter, const string& sRoomKey)
{
	if (m_bInMFW)
	{
		getCurrent()->setResponse(false);
		dispatchThreadPool(getHashCode(sRoomKey));
		return 0;
	}
    
    int32_t iRet = ChatManager::getInstance()->leaveChatRoom(iZoneId, iUid, iType, sFilter, sRoomKey);
    if (iRet != 0)
    {
        return iRet;
    }
	
    return 0;
}
    
int32_t ChatServiceImp::sendChat(const string &sRoomKey, uint32_t iZoneId, uint64_t iUid, const string &sData)
{
	if (m_bInMFW)
	{
		getCurrent()->setResponse(false);
		dispatchThreadPool(getHashCode(sRoomKey));
		return 0;
	}
    
    int32_t iRet = ChatManager::getInstance()->sendChat(sRoomKey, iZoneId, iUid, sData);
    if (iRet != 0)
    {
        return iRet;
    }
 
    return 0;
}
    
int32_t ChatServiceImp::showChatRoomInfo(const string &sRoomKey, string &sInfo)
{
	if (m_bInMFW)
	{
		getCurrent()->setResponse(false);
		dispatchThreadPool(getHashCode(sRoomKey));
		return 0;
	}
    
    int32_t iRet = ChatManager::getInstance()->showChatRoomInfo(sRoomKey, sInfo);
    if (iRet != 0)
    {
        return iRet;
    }
    
    return 0;
}
    
int32_t ChatServiceImp::joinChatRoomWithSize(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sFilter, uint32_t iSize, uint32_t iOldType, const string& sOldFilter, uint32_t iOldSize, const string& sOldRoomKey, string& sRoomKey)
{
	if (m_bInMFW)
	{
		getCurrent()->setResponse(false);
        // 88 hash 从filter改为iUid，join中的createRoom逻辑会可能重复创建多个，但是逻辑上可以接受
		//dispatchThreadPool(getHashCode(sFilter));
		dispatchThreadPool(getHashCode(UtilString::tostr(iUid)));
		return 0;
	}

    int32_t iRet = 0;

    if (iOldType != 0 && !sOldFilter.empty() && !sOldRoomKey.empty())
    {
        iRet = ChatManager::getInstance()->leaveChatRoom(iZoneId, iUid, iOldType, sOldFilter, sOldRoomKey, iOldSize);
        if (iRet != 0)
        {
            return iRet;
        }
    }
    
    iRet = ChatManager::getInstance()->joinChatRoom(iZoneId, iUid, iType, sFilter, sRoomKey, iSize);
    if (iRet != 0)
    {
        return iRet;
    }
 
    return 0;
}

int32_t ChatServiceImp::leaveChatRoomWithSize(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sFilter, uint32_t iSize, const string& sRoomKey)
{
	if (m_bInMFW)
	{
		getCurrent()->setResponse(false);
		dispatchThreadPool(getHashCode(sRoomKey));
		return 0;
	}
    
    int32_t iRet = ChatManager::getInstance()->leaveChatRoom(iZoneId, iUid, iType, sFilter, sRoomKey, iSize);
    if (iRet != 0)
    {
        return iRet;
    }
	
    return 0;
}

uint64_t ChatServiceImp::getHashCode(const string& sKey)
{
    map<string, uint64_t>::iterator ir = m_HashCode.find(sKey);
    if (ir != m_HashCode.end())
    {
        return ir->second;
    }
  
    uint64_t iHashCode = MurmurHash64B(sKey);
    //LOG_DEBUG("chat service imp hash key " << sKey << " hash code " << iHashCode); 
    
    return iHashCode;
}

void ChatServiceImp::dispatchThreadPool(uint64_t iHashCode)
{
	uint32_t iIndex = iHashCode % g_stChatServerConfig.iLogicThreadNum;
	CHAT_THREAD_QUEUE_MGR->pushToQueue(iIndex, getCurrent());
}



