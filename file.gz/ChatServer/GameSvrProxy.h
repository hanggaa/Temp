
#ifndef _GAME_SVR_PROXY_H_
#define _GAME_SVR_PROXY_H_

#include <stdint.h>
#include <map>
#include <tr1/memory>

#include "GameServer/Server/GameService/MTTD.GameService.h"
#include "util/util_singleton.h"
#include "util/util_thread.h"

using namespace mfw;

class GameSvrProxy : public MTTD::GameServicePrx
{
public:
	uint32_t m_iZoneId;

	MTTD::GameServicePrx& getGamePrx();

private:
	MTTD::GameServicePrx m_pGameServicePrx;
};

class GameSvrProxyMgr : public CSingleton <GameSvrProxyMgr>
{
public:
	GameSvrProxy* getGameSvrProxy(uint32_t iZoneId);

private:

	CMutex				             m_mutex;
	std::map<uint32_t, GameSvrProxy> m_mSvrProxy;
};

#endif
