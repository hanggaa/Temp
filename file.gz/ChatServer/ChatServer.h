#ifndef _CHATSERVER_H_
#define _CHATSERVER_H_

#include "service/Application.h"
using namespace mfw;

class ChatServer : public Application
{
public:
	virtual void initialize();
	virtual void destroyApp();
};

extern ChatServer g_app;

#endif
