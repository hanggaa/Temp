#ifndef _CHATSERVER_CONFIG_H_
#define _CHATSERVER_CONFIG_H_

#include <stdint.h>
#include <string>
#include <vector>
using namespace std;

struct ChatServerConfig
{
	string	        sChatRedisObj;
	string	        sGameServiceObj;

    uint32_t        iChatRoomSizeMax;

    uint32_t        iLogicThreadNum;

    uint32_t        iChatRecordMaxNum;

    uint32_t        iChatRoomExpireInterval;

    vector<string>  vLogChatLanguageExcept;

    vector<vector<string> >	vIgnoreChatKeyword;
};

extern ChatServerConfig g_stChatServerConfig;

int32_t loadChatServerConfig();

#endif
