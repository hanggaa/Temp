#include "ChatServerConfig.h"
#include "service/ApplicationConfig.h"
#include "util/util_config.h"
#include "util/util_log.h"
#include "util/util_string.h"

using namespace mfw;

ChatServerConfig g_stChatServerConfig;

int32_t loadChatServerConfig()
{
	__TRY__
	CConfig config;
	config.parseFile(ServerConfig::ServerName + ".conf");

	g_stChatServerConfig.sGameServiceObj = config.getCfg("/Main/GameServiceObj");
	g_stChatServerConfig.sChatRedisObj = config.getCfg("/Main/ChatRedisObj");
	
	g_stChatServerConfig.iChatRoomSizeMax = config.getCfg<uint32_t>("/Main/ChatRoomSizeMax");

    g_stChatServerConfig.iLogicThreadNum = config.getCfg<uint32_t>("/Main/LogicThreadNum");    

    g_stChatServerConfig.iChatRecordMaxNum = config.getCfg<uint32_t>("/Main/ChatRecordMaxNum");
    
    g_stChatServerConfig.iChatRoomExpireInterval = config.getCfg<uint32_t>("/Main/ChatRoomExpireInterval");
   
    g_stChatServerConfig.vLogChatLanguageExcept = UtilString::splitString(config.getCfg("/Main/LogChatLanguageExcept"), ",;");

    vector<string> vIgnoreStr = UtilString::splitString(config.getCfg("/Main/IgnoreChatKeyword", ""), ";", true);
    for (uint32_t i = 0; i < vIgnoreStr.size(); ++i)
    {
    	vector<string> vKeyword = UtilString::splitString(vIgnoreStr[i], ",", true);
    	if (!vKeyword.empty())
    	{
    		g_stChatServerConfig.vIgnoreChatKeyword.push_back(vKeyword);
    	}
    }

    return 0;
	__CATCH__
	return -1;
}
