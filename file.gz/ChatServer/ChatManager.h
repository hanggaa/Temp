#ifndef _CHATMANAGER_H_
#define _CHATMANAGER_H_

#include <stdint.h>
#include <map>
#include <string>
#include "util/util_stl.h"
#include <vector>

#include "redis/Redis.h"
#include "util/util_singleton.h"

namespace MTTD {
struct ChatRoomRecord;
struct ChatRoomRole;
struct ChatRoomZone;
}  // namespace MTTD

using namespace std;

class ChatRedisCallback : public mfw::RedisPrxCallback
{
public:
	ChatRedisCallback(const string& sF):
        sFilter(sF){}

	ChatRedisCallback(const string& sF, const string& sD):
        sFilter(sF), sData(sD){}

public:
    string  sFilter;	
    string	sData;

public:
	virtual void callback_getString(int32_t ret, const string &sValue);
	virtual void callback_getString_exception(int32_t ret);
	virtual void callback_setString(int32_t ret);
	virtual void callback_setString_exception(int32_t ret);
};

class RedisLock
{
    virtual uint64_t lock(string sLockKey) = 0;
    virtual void unlock(string sLockKey) = 0;
};

class ChatRedisLock : public RedisLock
{
public:
    void setRedisPrx(mfw::RedisPrx pRedisPrx) { m_pRedisPrx = pRedisPrx; }

    virtual uint64_t lock(string sLockKey);
    virtual void unlock(string sLockKey);

private:
    mfw::RedisPrx m_pRedisPrx;
};

typedef vector<uint64_t> RoleUidList;
typedef pair<string, uint32_t> RoleUidListKey;

typedef map<RoleUidListKey, RoleUidList> RoleUidListMap;
typedef RoleUidListMap::iterator RoleUidListMapItr;

class ChatManager : public mfw::CSingleton<ChatManager>
{
public:
    ChatManager();

    int32_t joinChatRoom(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sFilter, string& sRoomKey, uint32_t iRoomSize = 0);
    int32_t leaveChatRoom(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sOldFilter, const string& sOldRoomKey, uint32_t iRoomSize = 0);
    
    int32_t sendChat(const string &sRoomKey, uint32_t iZoneId, uint64_t iUid, const string &sData);
    int32_t showChatRoomInfo(const string &sRoomKey, string &sInfo);

public:
	int32_t getRedisRoomZoneList(const string& sRoomKey, vector<MTTD::ChatRoomZone>& vRoomZoneList);
	int32_t addRedisRoomZone(const string& sRoomKey, const MTTD::ChatRoomZone& stRoomZone);
	int32_t delRedisRoomZone(const string& sRoomKey, const MTTD::ChatRoomZone& stRoomZone);

	int32_t getRedisRoomRoleList(const string& sRoomKey, vector<MTTD::ChatRoomRole>& vRoomRoleList);
	int32_t addRedisRoomRole(const string& sRoomKey, const MTTD::ChatRoomRole& stRoomRole);
	int32_t delRedisRoomRole(const string& sRoomKey, const MTTD::ChatRoomRole& stRoomRole);

	int32_t getRedisRoomRecordList(const string& sRoomKey, vector<MTTD::ChatRoomRecord>& vRoomRecordList);
	int32_t addRedisRoomRecord(const string& sRoomKey, const MTTD::ChatRoomRecord& stRoomRecord);
	//int32_t delRedisRoomRecord(const string& sRoomKey, const MTTD::ChatRoomRecord& stRoomRecord);

public:  
    const string getValidChatRoom(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sFilter, uint32_t iRoomSize = 0);

private:
    uint64_t getMaxRoomIndex(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sFilter); 
    bool checkRoomRoleListNotFull(const string& sRoomKey, uint32_t iCountLimit);
    int32_t createRoom(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sFilter, string& sRoomKey);
    
    const string getRecentRoomKey(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sFilter); 
    int32_t setRecentRoomKey(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sFilter, const string& sRoomKey); 

private:
    mfw::RedisPrx m_pRedisPrx;

    ChatRedisLock   m_ChatLock;
};

#endif

