
#include <stddef.h>
#include <ostream>
#include <string>
#include "util/util_stl.h"

#include "ChatServerConfig.h"
#include "GameSvrProxy.h"
#include "service/Application.h"
#include "service/Connector.h"
#include "service/Global.h"
#include "util/util_log.h"
#include "util/util_string.h"

MTTD::GameServicePrx& GameSvrProxy::getGamePrx()
{
	if (m_pGameServicePrx != NULL)
	{
		return m_pGameServicePrx;
	}

	string sSvrProxy = g_stChatServerConfig.sGameServiceObj + "%moba.zone." + UtilString::tostr(m_iZoneId);
	m_pGameServicePrx = Application::getConnector()->stringToProxy<MTTD::GameServicePrx>(sSvrProxy);

	if (!m_pGameServicePrx)
	{
		LOG_DAYERROR("get game proxy faild. m_iZoneId = " << m_iZoneId << " m_iZoneId" << m_iZoneId);
	}

	return m_pGameServicePrx;
}

GameSvrProxy* GameSvrProxyMgr::getGameSvrProxy(uint32_t iZoneId)
{
    CLockGuard<CMutex> lock(m_mutex);
	
    std::map<uint32_t, GameSvrProxy>::iterator it = m_mSvrProxy.find(iZoneId);
	if (it != m_mSvrProxy.end())
	{
		return &(it->second);
	}

    GameSvrProxy stGameSvrProxy;
    stGameSvrProxy.m_iZoneId = iZoneId;
    m_mSvrProxy[iZoneId] = stGameSvrProxy;

	return &(m_mSvrProxy[iZoneId]);
}
