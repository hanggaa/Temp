#include <stddef.h>
#include <unistd.h>
#include <ostream>
#include <tr1/memory>

#include "Base/TimeHelper.h"
#include "ChatGame/MTTD.ChatRoomRecord.h"
#include "ChatGame/MTTD.ChatRoomType.h"
#include "ChatGame/MTTD.ChatRoomZone.h"
#include "ChatManager.h"
#include "ChatServerConfig.h"
#include "ChatService/../../Inter/ChatGame/MTTD.ChatRoomRole.h"
#include "ChatService/MTTD.ChatRoomInfo.h"
#include "ChatService/MTTD.Cmd_Notify_Chat_Simple.h"
#include "ErrorDefine/MTTD.ErrorCode.h"
#include "GameServer/Server/GameService/MTTD.GameService.h"
#include "GameServer/Server/GameService/MTTD.GameServiceMsg.h"
#include "GameSvrProxy.h"
#include "ProtoNotify/MTTDProto.CmdId_Notify.h"
#include "ProtoNotify/MTTDProto.Cmd_Notify_Chat.h"
#include "sdp/Sdp.h"
#include "service/Application.h"
#include "service/Connector.h"
#include "service/Global.h"
#include "util/util_log.h"
#include "util/util_string.h"
#include "util/util_time.h"

#define ROOM_LOCK_KEY                       "l"


#define ROOM_ZONELIST_KEY                   "zl"
#define ROOM_ROLELIST_KEY                   "rl"
#define ROOM_CHATRECORD_KEY                 "cr"
#define ROOM_MAX_COUNT_KEY                  "max:last_id"
#define ROOM_RECENT_KEY                     "rct" //最近创建或者离开的，提高效率


#define ROOM_LANGUAGE_KEY_PREFIX		    "l"
#define ROOM_COUNTRY_KEY_PREFIX		        "c:"

/*
暂时先不用加锁了
static string makeRoomLockKey(const string& sRoomKey)
{
    return ROOM_LOCK_KEY + sRoomKey;
}
*/

static string makeRoomZoneListKey(const string& sRoomKey)
{
    return ROOM_ZONELIST_KEY + sRoomKey;
}

static string makeRoomRoleListKey(const string& sRoomKey)
{
    return ROOM_ROLELIST_KEY + sRoomKey;
}

static string makeRoomRecordListKey(const string& sRoomKey)
{
    return ROOM_CHATRECORD_KEY + sRoomKey;
}

static string makeRoomKey(uint32_t iType, uint32_t /*iZoneId*/, uint64_t /*iUid*/, const string &sFilter, uint64_t iRoomMaxId )
{
    ostringstream sKey;
    if (iType == MTTD::ChatRoomType_Language)
    {
        sKey << ROOM_LANGUAGE_KEY_PREFIX << sFilter << UtilString::tostr(iRoomMaxId);// << "_" << UtilString::tostr(iZoneId) << "_" << UtilString::tostr(iUid);
	}
    else if (iType == MTTD::ChatRoomType_Country)
    {
        sKey << ROOM_COUNTRY_KEY_PREFIX << sFilter << UtilString::tostr(iRoomMaxId);// << "_" << UtilString::tostr(iZoneId) << "_" << UtilString::tostr(iUid);
    }
    
    return sKey.str();
}

static string makeRoomMaxKey(uint32_t iType, uint32_t /*iZoneId*/, uint64_t /*iUid*/, const string &sFilter)
{
    ostringstream sKey;
    if (iType == MTTD::ChatRoomType_Language)
    {
        sKey << ROOM_LANGUAGE_KEY_PREFIX << ROOM_MAX_COUNT_KEY << sFilter;
	}
    else if (iType == MTTD::ChatRoomType_Country)
    {
        sKey << ROOM_COUNTRY_KEY_PREFIX << ROOM_MAX_COUNT_KEY << sFilter;
    }
   
    return sKey.str();
}

static string makeRoomRecentKey(uint32_t iType, uint32_t /*iZoneId*/, uint64_t /*iUid*/, const string &sFilter)
{
    ostringstream sKey;
    if (iType == MTTD::ChatRoomType_Language)
    {
        sKey << ROOM_RECENT_KEY << ROOM_LANGUAGE_KEY_PREFIX << sFilter;
	}
    else if (iType == MTTD::ChatRoomType_Country)
    {
        sKey << ROOM_RECENT_KEY << ROOM_COUNTRY_KEY_PREFIX << sFilter;
    }
    
    return sKey.str();
}

ChatManager::ChatManager()
{
    m_pRedisPrx = Application::getConnector()->stringToProxy<mfw::RedisPrx>(g_stChatServerConfig.sChatRedisObj);

    //m_ChatLock.setRedisPrx(m_pRedisPrx);
}

int32_t ChatManager::joinChatRoom(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sFilter, string& sRoomKey, uint32_t iRoomSize /*= 0*/)
{
    if (iType != MTTD::ChatRoomType_Language
        && iType != MTTD::ChatRoomType_Country)
    {
        return MTTD::Error_Chat_InvalidFilter;
    }
    
    sRoomKey = getValidChatRoom(iZoneId, iUid, iType, sFilter, iRoomSize);
    if (sRoomKey.empty())
    { 
        int32_t iRet = createRoom(iZoneId, iUid, iType, sFilter, sRoomKey);
        if (iRet != 0)
        {
            LOG_DEBUG("join chat room create room failed" << iRet);
            return iRet;
        }
    }

    if (sRoomKey.empty())
    {
        return MTTD::Error_Chat_InvalidFilter;
    }

    MTTD::ChatRoomZone stRoomZone;
    stRoomZone.iZoneId = iZoneId;

    MTTD::ChatRoomRole stRoomRole;
    stRoomRole.iZoneId = iZoneId;
    stRoomRole.iUid = iUid;

    //addRedisRoomZone(sRoomKey, stRoomZone);
    addRedisRoomRole(sRoomKey, stRoomRole);

    LOG_DEBUG("join room zone id " << iZoneId << " uid " << iUid << " type " << iType << " filter " << sFilter << " room key " << sRoomKey);

    return 0;
}

int32_t ChatManager::leaveChatRoom(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sOldFilter, const string& sOldRoomKey, uint32_t iRoomSize /*= 0*/)
{
    if (sOldRoomKey.empty())
    {
        return MTTD::Error_Chat_InvalidRoomKey;
    }
    
    MTTD::ChatRoomZone stRoomZone;
    stRoomZone.iZoneId = iZoneId;

    MTTD::ChatRoomRole stRoomRole;
    stRoomRole.iZoneId = iZoneId;
    stRoomRole.iUid = iUid;

    //delRedisRoomZone(sOldRoomKey, stRoomZone);
    delRedisRoomRole(sOldRoomKey, stRoomRole);

    LOG_DEBUG("leave room zone id " << iZoneId << " uid " << iUid << " type " << iType << " old filter " << sOldFilter << " room old key " << sOldRoomKey);
  
    if (string::npos != sOldRoomKey.find(sOldFilter))
    {
        const string sRecentRoomKey = getRecentRoomKey(iZoneId, iUid, iType, sOldFilter);
        if (!sRecentRoomKey.empty())
        {
            if (iRoomSize <= 0)
            {
                iRoomSize = g_stChatServerConfig.iChatRoomSizeMax;
            }

            if (false == checkRoomRoleListNotFull(sRecentRoomKey, iRoomSize))
            {
                setRecentRoomKey(iZoneId, iUid, iType, sOldFilter, sOldRoomKey);
            }
        }
        else
        {
            setRecentRoomKey(iZoneId, iUid, iType, sOldFilter, sOldRoomKey);
        }
    }
    
    return 0;
}
    
int32_t ChatManager::sendChat(const string &sRoomKey, uint32_t iZoneId, uint64_t iUid, const string &sData)
{
    if (sRoomKey.empty())
    {
        return MTTD::Error_Chat_InvalidRoomKey;
    }

    if (!g_stChatServerConfig.vIgnoreChatKeyword.empty())
    {
    	try
    	{
			MTTD::Cmd_Notify_Chat_Simple stSimpleInfo;
			stringToSdp(sData, stSimpleInfo);

			for (uint32_t i = 0; i < g_stChatServerConfig.vIgnoreChatKeyword.size(); ++i)
			{
				const vector<string> &vKeyword = g_stChatServerConfig.vIgnoreChatKeyword[i];
				bool bAllMatch = true;
				for (uint32_t j = 0; j < vKeyword.size(); ++j)
				{
					if (!UtilString::isContains(stSimpleInfo.sMessage, vKeyword[j]))
					{
						bAllMatch = false;
						break;
					}
				}

				if (bAllMatch)
				{
					return 0;
				}
			}
    	}
    	catch (std::exception &e)
		{
			LOG_EXCEPTION(e.what());
			return 0;
		}
    }

    vector<MTTD::ChatRoomRole> vRoomRoleList;	
    /*
    int32_t iRet = getRedisRoomRoleList(sRoomKey, vRoomRoleList);
	if (iRet != 0)
	{
        LOG_DEBUG("get redis role list failed room key " << sRoomKey);
		return iRet;
	}
    */
    
    getRedisRoomRoleList(sRoomKey, vRoomRoleList);

   
    map<uint32_t, RoleUidList> mapZoneRoleUidList;
    map<uint32_t, RoleUidList>::iterator ir;

    for (uint32_t i = 0; i < vRoomRoleList.size(); ++i)
    {
        const MTTD::ChatRoomRole& stRoomRole = vRoomRoleList.at(i);
        
		if (stRoomRole.iZoneId == iZoneId
            && stRoomRole.iUid == iUid)
        {
			continue;
		}

        map<uint32_t, RoleUidList>::iterator ir = mapZoneRoleUidList.find(stRoomRole.iZoneId);
        if (ir == mapZoneRoleUidList.end())
        {
            RoleUidList list;
            list.push_back(stRoomRole.iUid);

            mapZoneRoleUidList.insert(pair<uint32_t, RoleUidList>(stRoomRole.iZoneId, list));
        }
        else
        {
            ir->second.push_back(stRoomRole.iUid);
        }
    }

    for (ir = mapZoneRoleUidList.begin(); ir != mapZoneRoleUidList.end(); ++ir)
    {
        uint32_t iZoneId = ir->first;
        RoleUidList& list = ir->second;

		GameSvrProxy* pGameSvrProxy = GameSvrProxyMgr::getInstance()->getGameSvrProxy(iZoneId);
		if (pGameSvrProxy != NULL && pGameSvrProxy->getGamePrx() != NULL)
		{
            //for (uint32_t i = 0; i < list.size(); ++i)
            {
                //uint64_t ulUid = list.at(i);

                MTTD::GameServiceMsg stMsg;
                stMsg.iMsgId = MTTDProto::CmdId_Notify_Chat;
                //stMsg.ulUid = ulUid;
                stMsg.vecUid = list;
                stMsg.sMsgData = sData;
                MTTD::GameServicePrxCallbackPtr cb;
                pGameSvrProxy->getGamePrx()->async_doCallGameService(cb, stMsg);
            }
		}
	}

    MTTD::ChatRoomRecord stRecord;
    stRecord.sData = sData;
    addRedisRoomRecord(sRoomKey, stRecord);

    LOG_DEBUG("send chat zone id " << iZoneId << " uid " << iUid << " room key " << sRoomKey);

    bool bNeedLog = true;
    for (unsigned i = 0; i < g_stChatServerConfig.vLogChatLanguageExcept.size(); ++i)
    {
        const string& sExcept = g_stChatServerConfig.vLogChatLanguageExcept[i];
        if (UtilString::isBeginsWith(sRoomKey, sExcept))
        {
            bNeedLog = false;
            break;
        }
    }
    
    if (true == bNeedLog)
    {
		MTTDProto::Cmd_Notify_Chat stInfo;
		stringToSdp(sData, stInfo);
        DAYLOG("sendchat", iZoneId << "|" << iUid << "|" << sRoomKey << "|" << CLogManager::escapeLogData(stInfo.sMessage));
    }
    
    return 0;
}
    
int32_t ChatManager::showChatRoomInfo(const string &sRoomKey, string &sInfo)
{
    if (sRoomKey.empty())
    {
        return MTTD::Error_Chat_InvalidRoomKey;
    }

    MTTD::ChatRoomInfo stRoomInfo;

    const std::string sRoomZLKey = makeRoomRoleListKey(sRoomKey);
    int32_t iRet = m_pRedisPrx->getSetCount(sRoomZLKey, stRoomInfo.iRoleNum);
    if (iRet != 0)
    {
        return iRet;
    }

    getRedisRoomRoleList(sRoomKey, stRoomInfo.vRoomRoleList);

    sInfo = sdpToString(stRoomInfo);

    return 0;
}


int32_t ChatManager::getRedisRoomZoneList(const string& sRoomKey, vector<MTTD::ChatRoomZone>& vRoomZoneList)
{
    if (sRoomKey.empty())
    {
        return MTTD::Error_Chat_InvalidRoomKey;
    }

    vector<string> vValue;
    const std::string sRoomZLKey = makeRoomZoneListKey(sRoomKey);
    int32_t iRet = m_pRedisPrx->getSetMember(sRoomZLKey, vValue);
    if (iRet != 0)
    {
        LOG_ERROR("fail to get redis room zone list data room key " << sRoomKey << " ret " << iRet);
        return iRet;
    }
    
    for (uint32_t i = 0; i < vValue.size(); ++i)
    {
        MTTD::ChatRoomZone stRoomZone;
        stringToSdp(vValue.at(i), stRoomZone);
        vRoomZoneList.push_back(stRoomZone);
    }
    
    return 0;
}

int32_t ChatManager::addRedisRoomZone(const string& sRoomKey, const MTTD::ChatRoomZone& stRoomZone)
{
    if (sRoomKey.empty())
    {
        return MTTD::Error_Chat_InvalidRoomKey;
    }

    std::string sValue = sdpToString(stRoomZone);
    
    bool bAdded = false;
    const std::string sRoomZLKey = makeRoomZoneListKey(sRoomKey);
    int32_t iRet = m_pRedisPrx->addSetMember(sRoomZLKey, sValue, bAdded);
    if (iRet != 0 && false == bAdded)
    {
        LOG_ERROR("fail to add redis room zone room key " << sRoomKey << " ret " << iRet << " added " << bAdded);
        return iRet;
    }
    
    return 0;
}

int32_t ChatManager::delRedisRoomZone(const string& sRoomKey, const MTTD::ChatRoomZone& stRoomZone)
{
    if (sRoomKey.empty())
    {
        return MTTD::Error_Chat_InvalidRoomKey;
    }

    std::string sValue = sdpToString(stRoomZone);
    
    bool bDeleted = false;
    const std::string sRoomZLKey = makeRoomZoneListKey(sRoomKey);
    int32_t iRet = m_pRedisPrx->delSetMember(sRoomZLKey, sValue, bDeleted);
    if (iRet != 0 && false == bDeleted)
    {
        LOG_ERROR("fail to add redis room zone room key " << sRoomKey << " ret " << iRet << " deleted " << bDeleted);
        return iRet;
    }
    
    return 0;
}


int32_t ChatManager::getRedisRoomRoleList(const string& sRoomKey, vector<MTTD::ChatRoomRole>& vRoomRoleList)
{
    if (sRoomKey.empty())
    {
        return MTTD::Error_Chat_InvalidRoomKey;
    }

    vector<string> vValue;
    const std::string sRoomZLKey = makeRoomRoleListKey(sRoomKey);
    int32_t iRet = m_pRedisPrx->getSetMember(sRoomZLKey, vValue);
    if (iRet != 0)
    {
        LOG_ERROR("fail to get redis room role list data room key " << sRoomKey << " ret " << iRet);
        return iRet;
    }

    iRet = m_pRedisPrx->setExpire(sRoomZLKey, g_stChatServerConfig.iChatRoomExpireInterval);
    if (iRet != 0)
    {
        LOG_ERROR("fail to set expire key " << sRoomZLKey << " ret " << iRet);
        return iRet;
    }

    for (uint32_t i = 0; i < vValue.size(); ++i)
    {
        MTTD::ChatRoomRole stRoomRole;
        stringToSdp(vValue.at(i), stRoomRole);
        vRoomRoleList.push_back(stRoomRole);
    }
    
    return 0;
}

int32_t ChatManager::addRedisRoomRole(const string& sRoomKey, const MTTD::ChatRoomRole& stRoomRole)
{
    if (sRoomKey.empty())
    {
        return MTTD::Error_Chat_InvalidRoomKey;
    }

    std::string sValue = sdpToString(stRoomRole);
    
    bool bAdded = false;
    const std::string sRoomZLKey = makeRoomRoleListKey(sRoomKey);
    int32_t iRet = m_pRedisPrx->addSetMember(sRoomZLKey, sValue, bAdded);
    if (iRet != 0 && false == bAdded)
    {
        LOG_ERROR("fail to add redis room role room key " << sRoomKey << " ret " << iRet << " added" << bAdded);
        return iRet;
    }
    
    iRet = m_pRedisPrx->setExpire(sRoomZLKey, g_stChatServerConfig.iChatRoomExpireInterval);
    if (iRet != 0)
    {
        LOG_ERROR("fail to set expire key " << sRoomZLKey << " ret " << iRet);
        return iRet;
    }

    return 0;
}

int32_t ChatManager::delRedisRoomRole(const string& sRoomKey, const MTTD::ChatRoomRole& stRoomRole)
{
    if (sRoomKey.empty())
    {
        return MTTD::Error_Chat_InvalidRoomKey;
    }

    std::string sValue = sdpToString(stRoomRole);
    
    bool bDeleted = false;
    const std::string sRoomZLKey = makeRoomRoleListKey(sRoomKey);
    int32_t iRet = m_pRedisPrx->delSetMember(sRoomZLKey, sValue, bDeleted);
    if (iRet != 0 && false == bDeleted)
    {
        LOG_ERROR("fail to add redis room role room key " << sRoomKey << " ret " << iRet << " deleted " << bDeleted);
        return iRet;
    }

    iRet = m_pRedisPrx->setExpire(sRoomZLKey, g_stChatServerConfig.iChatRoomExpireInterval);
    if (iRet != 0)
    {
        LOG_ERROR("fail to set expire key " << sRoomZLKey << " ret " << iRet);
        return iRet;
    }

    return 0;
}

int32_t ChatManager::getRedisRoomRecordList(const string& sRoomKey, vector<MTTD::ChatRoomRecord>& vRoomRecordList)
{
    if (sRoomKey.empty())
    {
        return MTTD::Error_Chat_InvalidRoomKey;
    }

    vector<string> vValue;
    const std::string sRoomZLKey = makeRoomRecordListKey(sRoomKey);
    int32_t iRet = m_pRedisPrx->getListByRange(sRoomZLKey, 0, -1, vValue);
    if (iRet != 0)
    {
        LOG_ERROR("fail to get redis room record list data room key " << sRoomKey << " ret " << iRet);
        return iRet;
    }
    
    for (uint32_t i = 0; i < vValue.size(); ++i)
    {
        MTTD::ChatRoomRecord stRoomRecord;
        stringToSdp(vValue.at(i), stRoomRecord);
        vRoomRecordList.push_back(stRoomRecord);
    }
    
    return 0;
}

int32_t ChatManager::addRedisRoomRecord(const string& sRoomKey, const MTTD::ChatRoomRecord& stRoomRecord)
{
    if (sRoomKey.empty())
    {
        return MTTD::Error_Chat_InvalidRoomKey;
    }

    std::string sValue = sdpToString(stRoomRecord);
   
    uint32_t iLen = 0; 
    const std::string sRoomZLKey = makeRoomRecordListKey(sRoomKey);
    int32_t iRet = m_pRedisPrx->pushListBack(sRoomZLKey, sValue, iLen);
    if (iRet != 0)
    {
        LOG_ERROR("fail to add redis room record room key " << sRoomZLKey << " ret " << iRet << " len " << iLen);
        return iRet;
    }

    iRet = m_pRedisPrx->setExpire(sRoomZLKey, g_stChatServerConfig.iChatRoomExpireInterval);
    if (iRet != 0)
    {
        LOG_ERROR("fail to set expiret key " << sRoomZLKey << " ret " << iRet);
        return iRet;
    }

    if (iLen > g_stChatServerConfig.iChatRecordMaxNum)
    {
        uint32_t iDelete = iLen - g_stChatServerConfig.iChatRecordMaxNum;
        iRet = m_pRedisPrx->trimList(sRoomZLKey, iDelete, -1);
        if (iRet != 0)
        {
            LOG_ERROR("fail to trim redis room record room key " << sRoomKey << " ret " << iRet << " delete " << iDelete);
            return iRet;
        }
    }
         
    return 0;
}

const string ChatManager::getValidChatRoom(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sFilter, uint32_t iRoomSize /*= 0*/)
{
    // 找最近创建或者离开的
    if (iRoomSize <= 0)
    {
        iRoomSize = g_stChatServerConfig.iChatRoomSizeMax;
    }

    const string sRecentRoomKey = getRecentRoomKey(iZoneId, iUid, iType, sFilter);
    if (!sRecentRoomKey.empty())
    {
        if (true == checkRoomRoleListNotFull(sRecentRoomKey, iRoomSize))
        {
            return sRecentRoomKey;
        }
    }
    
    uint64_t iRoomMaxId = getMaxRoomIndex(iZoneId, iUid, iType, sFilter);
    if (iRoomMaxId == 0)
    {
        return "";
    }

    for (uint64_t iRoomId = iRoomMaxId; iRoomId > 0; iRoomId--)
    {
        const string sRoomKeyTemp = makeRoomKey(iType, iZoneId, iUid, sFilter, iRoomId);
        if (true == checkRoomRoleListNotFull(sRoomKeyTemp, iRoomSize))
        {
            setRecentRoomKey(iZoneId, iUid, iType, sFilter, sRoomKeyTemp);
            
            return sRoomKeyTemp;
        }
    }

    return "";
}

uint64_t ChatManager::getMaxRoomIndex(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sFilter)
{
    string sRoomMaxKey = makeRoomMaxKey(iType, iZoneId, iUid, sFilter);
    if (sRoomMaxKey.empty())
    {
		LOG_ERROR("empty room max key " << iType << " zone id " << iZoneId << " uid " << iUid << " filter " << sFilter);
        return 0;
    }
 
    string sValue;
	int32_t ret = m_pRedisPrx->getString(sRoomMaxKey, sValue);
	if (ret != 0)
	{
		LOG_ERROR("fail to get redis room max data room max key " << sRoomMaxKey << " ret " << ret);
        return 0;
    }

    return UtilString::strto<uint64_t>(sValue); 
}
    
const string ChatManager::getRecentRoomKey(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sFilter)
{
    string sRecentRoomKey = makeRoomRecentKey(iType, iZoneId, iUid, sFilter);
    if (sRecentRoomKey.empty())
    {
		LOG_ERROR("empty room recent key " << iType << " zone id " << iZoneId << " uid " << iUid << " filter " << sFilter);
        return "";
    }
 
    string sValue;
	int32_t ret = m_pRedisPrx->getString(sRecentRoomKey, sValue);
	if (ret != 0)
	{
		LOG_ERROR("fail to get redis room recent data room recent key " << sRecentRoomKey << " ret " << ret);
        return "";
    }

    return sValue;
}

int32_t ChatManager::setRecentRoomKey(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sFilter, const string& sRoomKey)
{
    string sRecentRoomKey = makeRoomRecentKey(iType, iZoneId, iUid, sFilter);
    if (sRecentRoomKey.empty())
    {
		LOG_ERROR("empty room recent key " << iType << " zone id " << iZoneId << " uid " << iUid << " filter " << sFilter);
        return MTTD::Error_InvalidParam;
    }
 
	int32_t ret = m_pRedisPrx->setString(sRecentRoomKey, sRoomKey);
	if (ret != 0)
	{
		LOG_ERROR("fail to get redis room recent data room recent key " << sRecentRoomKey << " ret " << ret);
        return ret;
    }

    return 0;
}

bool ChatManager::checkRoomRoleListNotFull(const string& sRoomKey, uint32_t iCountLimit)
{
    if (sRoomKey.empty())
    {
        return false;
    }
    
    const string sRoomRLKey = makeRoomRoleListKey(sRoomKey);

    // 过期被删除的也是可以直接使用的,因为被删除的返回值依然是0
    uint32_t iCount = 0;
    int32_t iRet = m_pRedisPrx->getSetCount(sRoomRLKey, iCount);
    if (iRet != 0)
    {
        LOG_DEBUG("check room role list key " << sRoomRLKey << " failed");
        return false;
    }

    return iCount < iCountLimit;
}


int32_t ChatManager::createRoom(uint32_t iZoneId, uint64_t iUid, uint32_t iType, const string& sFilter, string& sRoomKey)
{
    string sRoomMaxKey = makeRoomMaxKey(iType, iZoneId, iUid, sFilter);
    if (sRoomMaxKey.empty())
    {
        return MTTD::Error_InvalidParam;
    }
	
    vector<string> sIncrCmd;
	sIncrCmd.push_back("incr");
	sIncrCmd.push_back(sRoomMaxKey);

	string sResult;
	int32_t ret = m_pRedisPrx->call(sIncrCmd, sResult);
	if (ret != 0)
	{
		return ret;
	}

	// incr返回":数字\r\n"
	if (sResult.size() < 3 || sResult[0] != ':'
			|| sResult[sResult.size() - 2] != '\r' || sResult[sResult.size() - 1] != '\n')
	{
		return MTTD::Error_Unknown;
	}

    uint64_t iRoomMaxId =  UtilString::strto<uint64_t>(sResult.substr(1, sResult.size() - 3));
    
    sRoomKey = makeRoomKey(iType, iZoneId, iUid, sFilter, iRoomMaxId);

    setRecentRoomKey(iZoneId, iUid, iType, sFilter, sRoomKey);

    LOG_DEBUG("create room max id " << iRoomMaxId << " room key " << sRoomKey);

    return 0;
}

/////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////
void ChatRedisCallback::callback_getString(int32_t /*ret*/, const string &/*sValue*/)
{
	static uint32_t uiLastTime = getNow();
	static uint32_t uiCnt = 0;
	uiCnt++;
	if (uiLastTime + 60 < getNow())
	{
		LOG_DEBUG("callback_getString cnt=" << uiCnt);
		uiLastTime = getNow();
		uiCnt = 0;
	}
}

void ChatRedisCallback::callback_getString_exception(int32_t ret)
{
	LOG_DAYERROR("callback_getString_exception filter " << sFilter << " ret " << ret );
}

void ChatRedisCallback::callback_setString(int32_t ret)
{
	static uint32_t uiLastTime = getNow();
	static uint32_t uiCnt = 0;
	uiCnt++;
	if (uiLastTime + 60 < getNow())
	{
		LOG_DEBUG("callback_setString cnt=" << uiCnt);
		uiLastTime = getNow();
		uiCnt = 0;
	}

	if (ret != 0)
	{
		LOG_DAYERROR("callback_setString filter " << sFilter << " ret " << ret);
	}
}

void ChatRedisCallback::callback_setString_exception(int32_t ret)
{
	LOG_DAYERROR("callback_setString_exception filter " << sFilter << " ret " << ret);
}

uint64_t ChatRedisLock::lock(string sLockKey)
{
    __TRY__
    LOG_DEBUG("begin chat redis lock");
    //循环获取锁
    while (true) 
    {
		bool bSuccess = false;
		int32_t ret = m_pRedisPrx->setStringWithOption(sLockKey, UtilString::tostr(UtilTime::getNow()), RedisProxy::SetCmdOption_NX, 10 * 1000, bSuccess);
        if (ret != 0 || false == bSuccess)
        {
            LOG_DEBUG("get lock failed---------");
            usleep(100);
            continue;
        }
        else
        {
            LOG_DEBUG("get lock sucess++++++++++");
            break;
        }
    }
    __CATCH__
    return 0;
}

void ChatRedisLock::unlock(string sLockKey)
{
    __TRY__
    LOG_DEBUG("begin chat redis lock");
    int32_t ret = m_pRedisPrx->delString(sLockKey);
    if (ret != 0)
    {
        LOG_DEBUG("unlock failed-----------");
    }
    else
    {
        LOG_DEBUG("unlock success+++++++++");
    }
    __CATCH__
    return;
}






