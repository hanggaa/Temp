
#include <map>
#include <ostream>
#include <string>

#include "ChatServer/ChatServiceImp.h"
#include "ChatThreadPool.h"
#include "service/SdpCurrent.h"
#include "util/util_log.h"
#include "util/util_string.h"

ChatThreadQueueMgr::ChatThreadQueueMgr()
{}

ChatThreadQueueMgr::~ChatThreadQueueMgr()
{}

int32_t ChatThreadQueueMgr::initialize(uint32_t iThreadNum)
{
	for (uint32_t i = 0; i < iThreadNum; ++i)
	{
		ChatThreadQueuePtr ptrChatThreadQueue(new ChatThreadQueue());
		m_vThreadQueue.push_back(ptrChatThreadQueue);
	}

	LOG_INFO("Thread Queue num = " << iThreadNum);
	return 0;
}

int32_t ChatThreadQueueMgr::pushToQueue(uint32_t iIndex, mfw::SdpCurrentPtr& stSdpCurrentPtr)
{
	if (iIndex > m_vThreadQueue.size() - 1)
	{
		LOG_ERROR("iIndex is outrange, iIndex = " << iIndex);
		return -1;
	}

	m_vThreadQueue[iIndex]->enqueue(stSdpCurrentPtr);
	return 0;
}

int32_t ChatThreadQueueMgr::getThreadQueue(uint32_t iIndex, ChatThreadQueuePtr& ptrThreadQueue)
{
	if (iIndex > m_vThreadQueue.size() - 1)
	{
		LOG_ERROR("iIndex is outrange, iIndex = " << iIndex);
		return -1;
	}

	ptrThreadQueue = m_vThreadQueue[iIndex];
	return 0;
}

void ChatThread::run()
{
	m_stChatServiceImp.setInMFW(false);
	m_stChatServiceImp.setForcePackResponse(true);
	mfw::CThread& stCThread = getThread();

	ChatThreadQueuePtr ptrThreadQueue;
	int32_t iRet = CHAT_THREAD_QUEUE_MGR->getThreadQueue(m_iThreadId, ptrThreadQueue);
	if (iRet != 0)
	{
		LOG_ERROR("getThreadQueue failed and texist, ThreadId: " << m_iThreadId);
		return;
	}

	while (!stCThread.isTerminate())
	{
		__TRY__
        mfw::SdpCurrentPtr stSdpCurrentPtr;
        if (ptrThreadQueue->dequeue(stSdpCurrentPtr, 20))
        {
            LOG_DEBUG("get msg, m_iThreadId: " << m_iThreadId);
            m_stChatServiceImp.setCurrent(stSdpCurrentPtr);
            string sRspPayload;
            int32_t iMfwRet = m_stChatServiceImp.handleMfwRequest(sRspPayload);
            //				m_stChatServiceImp.getCurrent()->setResponse(true);
            //				int32_t iMfwRet = m_stChatServiceImp.handleMfwRequest(sRspPayload);
            m_stChatServiceImp.getCurrent()->sendMfwResponse(iMfwRet, sRspPayload);
        }

		__CATCH__
	}
}

ChatThreadPool::ChatThreadPool()
{}

ChatThreadPool::~ChatThreadPool()
{}

int32_t ChatThreadPool::initialize(uint32_t iThreadNum)
{
	for (uint32_t i = 0; i < iThreadNum; ++i)
	{
		ChatThreadPtr ptrChatThread(new ChatThread());
		ptrChatThread->setThreadId(i);
		ptrChatThread->start("ChatLogic_" + mfw::UtilString::tostr(i));

		m_vChatThreadPtr.push_back(ptrChatThread);
	}

	LOG_INFO("Logic Thread num = " << iThreadNum);
	return 0;
}

int32_t ChatThreadPool::finalize()
{
	for (uint32_t i = 0; i < m_vChatThreadPtr.size(); ++i)
	{
		ChatThreadPtr& stChatThreadPtr = m_vChatThreadPtr[i];

		stChatThreadPtr->stop();
	}

	m_vChatThreadPtr.clear();
	return 0;
}
