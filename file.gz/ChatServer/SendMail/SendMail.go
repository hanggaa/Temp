package main

import (
	"bufio"
	"bytes"
	"encoding/base64"
	"errors"
	"flag"
	"fmt"
	"io"
	"io/ioutil"
	"mfw/mfwutil/mfwlog"
	"mfw/mfwutil/mfwstring"
	"net/smtp"
	"os"
	"strings"
	"sync"
	"text/template"
)

type SmtpUserConfig struct {
	smtpUser     string
	smtpPass     string
	mailFromAddr string
	mailFromName string
}

var (
	smtpAuth smtp.Auth
	//smtpAddr        = "smtp2525.sendcloud.net:2525"
	smtpAddr        = "hksmtp.sendcloud.net:2525"
	smtpUser        string
	smtpPass        string
	mailFromAddr    string
	mailFromName    string
	mailToAddrs     []string
	mailtoFile      string
	templateContent string
	templateBody    string
	templateSubject string
	mailImageFiles  string
	mailImagesBins  string
	sendThreads     = 20
	smtpUsers       = map[string]SmtpUserConfig{
		"Moonton_survey2": SmtpUserConfig{"Moonton_survey2", "caEhi300ab62sEMQ", "donotreply@survey-sc.moonton.com", "Mobile Legends:Bang Bang"},
		"Moonton_formal":  SmtpUserConfig{"Moonton_formal", "XmbxhXCLlk8AmMjY", "donotreply@register-sc.moonton.com", "Mobile Legends:Bang Bang"},
		"Moonton_market":  SmtpUserConfig{"Moonton_market", "15517c255bb829be2b6d60728ff50cce", "donotreply@market-sc.moonton.com", "Mobile Legends:Bang Bang"},
		"Moonton_service": SmtpUserConfig{"Moonton_serivce", "C9COn9z7cAF5vlOs", "donotreply@service-sc.moonton.com", "Mobile Legends:Bang Bang"}}
)

func parseArgs() error {
	flag.StringVar(&smtpAddr, "addr", smtpAddr, "SMTP地址")
	flag.StringVar(&smtpUser, "user", smtpUser, "SMTP账号[Moonton_market]")
	flag.StringVar(&smtpPass, "pass", smtpPass, "SMTP密码")
	flag.StringVar(&mailFromAddr, "from", mailFromAddr, "From邮件地址")
	flag.StringVar(&mailFromName, "from-name", mailFromName, "From邮件名字")
	to := flag.String("to", "", "To邮件地址")
	flag.StringVar(&mailtoFile, "to-file", mailtoFile, "To邮件地址列表文件")
	mailContentFile := flag.String("content-file", "", "邮件内容模板")
	mailBodyFile := flag.String("body-file", "", "邮件正文模板")
	flag.IntVar(&sendThreads, "threads", sendThreads, "发送线程")
	flag.StringVar(&mailImageFiles, "image-file", mailImageFiles, "图片列表")
	flag.Parse()

	if len(smtpUsers) < 1 {
		return fmt.Errorf("smtp user empty, check tools code")
	}

	stUserConfig, ok := smtpUsers[smtpUser]
	if !ok {
		return fmt.Errorf("smtp user empty: %s", smtpUser)
	}

	smtpPass = stUserConfig.smtpPass
	mailFromAddr = stUserConfig.mailFromAddr
	mailFromName = stUserConfig.mailFromName

	smtpAuth = LoginAuth(smtpUser, smtpPass)
	mailToAddrs = mfwstring.SplitString(*to, ",;", true)

	if *mailContentFile != "" {
		data, err := ioutil.ReadFile(*mailContentFile)
		if err != nil {
			return fmt.Errorf("fail to open file: %s", *mailContentFile)
		}
		templateContent = string(data)
	}
	if templateContent == "" {
		return fmt.Errorf("missing mail conent")
	}

	if *mailBodyFile != "" {
		data, err := ioutil.ReadFile(*mailBodyFile)
		if err != nil {
			return fmt.Errorf("fail to open file: %s", *mailBodyFile)
		}
		items := strings.SplitN(string(data), "\n", 2)
		if len(items) != 2 {
			return fmt.Errorf("invalid body")
		}
		templateSubject = items[0]
		templateBody = items[1]
	}
	if templateSubject == "" || templateBody == "" {
		return fmt.Errorf("missing mail subject/content")
	}

	if mailImageFiles != "" {
		vFiles := mfwstring.SplitString(mailImageFiles, ",", true)
		buffer := bytes.NewBuffer(nil)
		for iNum, sFileName := range vFiles {
			data, err := ioutil.ReadFile(sFileName)
			if err != nil {
				return fmt.Errorf("fail to open file: %s", sFileName)
			}

			sBase64 := base64.StdEncoding.EncodeToString(data)
			sFullFileName := "ml_email_image" + fmt.Sprint(iNum+1)

			buffer.WriteString("--FILEBOUNDARY\n")
			buffer.WriteString("Content-Type: image/jpeg;\n")
			buffer.WriteString("Content-Disposition: inline; filename=\"=?utf-8?B?" + base64.StdEncoding.EncodeToString([]byte(sFullFileName)) + "?=\"\n")
			buffer.WriteString("Content-ID:<contentid_" + sFullFileName + ">\n")
			buffer.WriteString("Content-Transfer-Encoding: base64\n")
			buffer.WriteString("\n")
			for i, l := 0, len(sBase64); i < l; i++ {
				buffer.WriteByte(sBase64[i])
				if (i+1)%72 == 0 {
					buffer.WriteString("\n")
				}
			}
			buffer.WriteString("\n")
		}
		mailImagesBins = buffer.String()
	}
	return nil
}

func main() {
	err := parseArgs()
	if err != nil {
		fmt.Println(err)
		return
	}

	mfwlog.InitLog(".", "-", 0, 0)
	mfwlog.SetLogLevel("DEBUG")
	defer mfwlog.FiniLog()

	tpl := template.Must(template.New("content").Parse(templateContent))
	ch := make(chan string, sendThreads)
	wg := &sync.WaitGroup{}
	wg.Add(sendThreads)
	for i := 0; i < sendThreads; i++ {
		go func() {
			defer wg.Done()
			for {
				select {
				case to, ok := <-ch:
					if !ok {
						return
					}

					err := sendmail(to, tpl, templateSubject, templateBody, mailImagesBins)
					if err != nil {
						mfwlog.Debug("send failed: %s, err: %v", to, err)
					} else {
						mfwlog.Debug("send ok: %s", to)
					}
				}
			}
		}()
	}

	defer func() {
		close(ch)
		wg.Wait()
	}()

	if len(mailToAddrs) != 0 {
		for _, to := range mailToAddrs {
			ch <- to
		}
	}
	if mailtoFile != "" {
		f, err := os.Open(mailtoFile)
		if err != nil {
			mfwlog.Error("fail to open file: %s, err: %v", mailtoFile, err)
			return
		}
		defer f.Close()

		bio := bufio.NewReader(f)
		for {
			line, err := bio.ReadString('\n')
			line = strings.TrimSpace(line)
			if line != "" {
				ch <- line
			}

			if err == io.EOF {
				break
			}
		}
	}
}

type MailData struct {
	MailFrom          string
	MailTo            string
	ReplyTo           string
	MailSubjectBase64 string
	MailContentBase64 string
	MailImageBase64   string
}

func sendmail(to string, tpl *template.Template, subject string, body string, image string) error {
	var buf bytes.Buffer
	data := MailData{
		MailFrom:          "\"=?UTF-8?B?" + base64.StdEncoding.EncodeToString([]byte(mailFromName)) + "?=\" <" + mailFromAddr + ">",
		ReplyTo:           mailFromAddr,
		MailTo:            to,
		MailSubjectBase64: base64.StdEncoding.EncodeToString([]byte(subject)),
		MailContentBase64: base64.StdEncoding.EncodeToString([]byte(body)),
		MailImageBase64:   image,
	}
	err := tpl.Execute(&buf, data)
	if err != nil {
		return err
	}

	msg := strings.Replace(buf.String(), "\n", "\r\n", -1)
	err = smtp.SendMail(smtpAddr, smtpAuth, mailFromAddr, []string{data.MailTo}, []byte(msg))
	if err != nil {
		return err
	}
	return nil
}

type loginAuth struct {
	username, password string
}

func LoginAuth(username, password string) smtp.Auth {
	return &loginAuth{username, password}
}

func (a *loginAuth) Start(server *smtp.ServerInfo) (string, []byte, error) {
	return "LOGIN", []byte{}, nil
}

func (a *loginAuth) Next(fromServer []byte, more bool) ([]byte, error) {
	if more {
		switch string(fromServer) {
		case "Username:":
			return []byte(a.username), nil
		case "Password:":
			return []byte(a.password), nil
		default:
			return nil, errors.New("Unkown fromServer")
		}
	}
	return nil, nil
}
