给玩家发送邮件，需要运营提供邮件地址列表、邮件标题、邮件正文

邮件地址列表：一行一个，放在比入id-email.txt文本文件中
邮件标题、正文：放在body.txt中，第一行为标题，第二行起为正文，正文是html格式的
邮件格式：放在content.txt中，一般不需要更改，如果有所调整，可能也需要同步修改代码

执行：
./SendMail -to-file id-email.txt -content-file content.txt -body-file body.txt > result.txt &

查看失败：
cat result.txt | grep -v ok


注意：采用sendcloud发送邮件，每天有数量上限，与moonton账号公用限额，当前限额是16w封/天。
